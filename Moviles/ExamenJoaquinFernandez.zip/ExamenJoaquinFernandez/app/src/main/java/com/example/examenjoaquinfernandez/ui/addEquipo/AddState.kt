package com.example.examenjoaquinfernandez.ui.addEquipo

import com.example.examenjoaquinfernandez.domain.model.Equipo

data class AddState (
    val equipo: Equipo? =null,
    val error: String? = null,
        )