package com.example.examenjoaquinfernandez.ui.listaEquipos

interface Actions {
    fun onClickDelete(nombre: String)
    fun onClickDetail(nombre: String)
}