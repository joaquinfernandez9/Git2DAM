package com.example.examenjoaquinfernandez.domain.model

data class Componente (
    val nombre: String,
    val tipo: String,
        )