package com.example.examenjoaquinfernandez.ui.addEquipo

interface Actions {
}