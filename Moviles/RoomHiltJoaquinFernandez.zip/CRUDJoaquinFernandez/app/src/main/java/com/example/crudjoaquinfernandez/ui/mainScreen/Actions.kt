package com.example.crudjoaquinfernandez.ui.mainScreen

interface Actions {
    fun onClickDelete(id: Int)
}