package com.example.crudjoaquinfernandez.ui.mainScreen

object Const {
    const val s = "Error cosas"
}