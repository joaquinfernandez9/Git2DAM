package com.example.crudjoaquinfernandez.ui.recycler

interface Actions {
    fun onClickDelete(id: Int)
    fun onClickDetail(id: Int)
}