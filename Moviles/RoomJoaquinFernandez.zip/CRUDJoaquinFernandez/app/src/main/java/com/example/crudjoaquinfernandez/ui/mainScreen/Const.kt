package com.example.crudjoaquinfernandez.ui.mainScreen

object Const {
    const val unknownvmc = "Unknown ViewModel class"
    const val uncheckedCast = "UNCHECKED_CAST"
    const val error = "error"
    const val id = "id"
    const val picURL =  "https://images.ecestaticos.com/FPDLmoNTTTzZeuuEMqvGze2X41A=/0x0:1183x665/1200x675/filters:fill(white):format(jpg)/f.elconfidencial.com%2Foriginal%2F5e5%2F157%2F764%2F5e5157764ad17f8e7ae6ead0618c5fdb.jpg"

}