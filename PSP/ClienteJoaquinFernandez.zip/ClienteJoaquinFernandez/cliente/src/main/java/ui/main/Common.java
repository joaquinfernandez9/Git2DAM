package ui.main;

public class Common {
    public static final String FXML_PRINCIPAL_FXML = "/fxml/principal.fxml";
    public static final String NEWSPAPER = "Newspaper";

    public Common() {
    }

}
