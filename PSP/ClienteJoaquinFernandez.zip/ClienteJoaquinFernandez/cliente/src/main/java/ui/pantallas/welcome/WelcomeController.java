package ui.pantallas.welcome;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import ui.pantallas.common.BasePantallaController;
import ui.pantallas.common.UiConstants;

public class WelcomeController extends BasePantallaController {


}
