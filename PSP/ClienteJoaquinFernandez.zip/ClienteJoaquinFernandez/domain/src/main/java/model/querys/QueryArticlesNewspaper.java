package model.querys;

import lombok.Data;

@Data
public class QueryArticlesNewspaper {
    private String name_article;
    private String name_newspaper;
}
