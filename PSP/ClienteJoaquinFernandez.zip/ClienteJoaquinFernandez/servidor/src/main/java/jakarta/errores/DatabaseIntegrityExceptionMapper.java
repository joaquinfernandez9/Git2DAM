package jakarta.errores;

public class DatabaseIntegrityExceptionMapper extends RuntimeException {
    public DatabaseIntegrityExceptionMapper(String message) {
        super(message);
    }
}
