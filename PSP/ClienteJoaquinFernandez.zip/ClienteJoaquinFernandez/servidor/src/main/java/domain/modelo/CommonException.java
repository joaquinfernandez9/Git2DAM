package domain.modelo;

public class CommonException extends RuntimeException {

    public CommonException(String message) {
        super(message);
    }

}
