package config;

public class Const {
    public static final String CONFIG_CONFIG_YAML = "/config/config.yaml";
    public static final String URL = "url";
    public static final String PASSWORD = "password";
    public static final String USER = "user";
    public static final String DRIVER = "driver";
}
