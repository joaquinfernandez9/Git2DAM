package jakarta.rest.jax;

import jakarta.rest.Const;
import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath(Const.API)
public class JAXRSApplication extends Application {}
