package dao.retrofit.cards;

import lombok.Data;

import java.util.List;
@Data
public class CardsList {
	private List<DataItem> data;
}