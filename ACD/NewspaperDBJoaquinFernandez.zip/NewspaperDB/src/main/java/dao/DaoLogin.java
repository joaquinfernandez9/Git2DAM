package dao;

public interface DaoLogin {
    boolean login(String userName, String password);
}
