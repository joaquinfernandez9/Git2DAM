package dao;

import domain.modelo.ReadArticle;
import io.vavr.control.Either;

public interface DaoReadArticle {
    Either<String, Boolean> add(int idReader, ReadArticle readArticle);
}
