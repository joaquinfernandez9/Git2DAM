package ui.pantallas.login;

import lombok.Data;

@Data
public class LoginState {

    private final boolean loginCorrecto;
    private final String mensaje;
}
