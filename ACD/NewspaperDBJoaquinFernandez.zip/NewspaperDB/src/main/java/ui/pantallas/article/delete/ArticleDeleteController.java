package ui.pantallas.article.delete;

import ui.pantallas.common.BasePantallaController;

public class ArticleDeleteController extends BasePantallaController {
}
