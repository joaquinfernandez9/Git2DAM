package ui.pantallas.newspaper.update;

import ui.pantallas.common.BasePantallaController;

public class NewsUpdateController extends BasePantallaController {
}
