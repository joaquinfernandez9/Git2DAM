package ui.pantallas.welcome;

import ui.pantallas.common.BasePantallaController;

public class WelcomeController extends BasePantallaController {
}
