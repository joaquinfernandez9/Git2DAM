package ui.pantallas.article.update;

import ui.pantallas.common.BasePantallaController;

public class ArticleUpdateController extends BasePantallaController {
}
