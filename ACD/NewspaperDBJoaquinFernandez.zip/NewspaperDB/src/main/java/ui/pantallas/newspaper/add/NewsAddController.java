package ui.pantallas.newspaper.add;

import ui.pantallas.common.BasePantallaController;

public class NewsAddController extends BasePantallaController {
}
