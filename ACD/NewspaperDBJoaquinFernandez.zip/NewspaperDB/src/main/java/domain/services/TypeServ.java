package domain.services;

import domain.modelo.ArticleType;

import java.util.List;

public interface TypeServ {
    List<ArticleType> getAll();
}
