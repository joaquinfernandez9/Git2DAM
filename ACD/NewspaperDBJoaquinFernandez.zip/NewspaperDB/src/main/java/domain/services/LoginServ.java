package domain.services;

public interface LoginServ {
    boolean login(String userName, String password);
}
