package domain.services.strings;

public class ServConstants {
    public static final String CANT_OPERATE = "Cant operate";
    public static final String ERROR = "Error";

    private ServConstants(){}
}
