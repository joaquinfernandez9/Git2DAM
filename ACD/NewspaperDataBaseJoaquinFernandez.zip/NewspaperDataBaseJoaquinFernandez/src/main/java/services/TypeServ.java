package services;

import model.ArticleType;

import java.util.List;

public interface TypeServ {
    List<ArticleType> getAll();
}
